@echo off
set COMPILER_PATH=C:\Users\ozere\AppData\Local\Microsoft\WinGet\Packages\MartinStorsjo.LLVM-MinGW.UCRT_Microsoft.Winget.Source_8wekyb3d8bbwe\llvm-mingw-20260616-ucrt-x86_64\bin
set GXX=%COMPILER_PATH%\i686-w64-mingw32-g++.exe
set GCC=%COMPILER_PATH%\i686-w64-mingw32-gcc.exe

echo [*] Building preview dependencies...
%GXX% -O2 -std=c++17 -c imgui/imgui.cpp -o p_imgui.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/imgui_draw.cpp -o p_draw.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/imgui_tables.cpp -o p_tables.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/imgui_widgets.cpp -o p_widgets.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/backends/imgui_impl_win32.cpp -o p_win32.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/backends/imgui_impl_opengl2.cpp -o p_gl2.o -Iimgui

echo [*] Building toker_preview.exe...
%GXX% -O2 -std=c++17 preview/preview.cpp p_imgui.o p_draw.o p_tables.o p_widgets.o p_win32.o p_gl2.o -o toker_preview.exe -Iimgui -lopengl32 -lgdi32 -luser32 -ldwmapi -static -s

del p_*.o
echo [!] Done: toker_preview.exe
