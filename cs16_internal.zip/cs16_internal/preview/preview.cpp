// C++17, x86, Windows — offline preview harness for the Toker menu.
// Builds the exact ui.h used in-game, renders N frames to an OpenGL window,
// dumps the last frame to BMP. Usage: toker_preview.exe <page> <out.bmp>
#include <windows.h>
#include <GL/gl.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "../src/ui.h"
#include "../imgui/backends/imgui_impl_win32.h"
#include "../imgui/backends/imgui_impl_opengl2.h"

static HWND g_wnd = nullptr;
static HDC g_dc = nullptr;
static HGLRC g_rc = nullptr;
static int W = 1280, H = 800;

// a crude map-like backdrop so the frosted glass has something to chew on
static void draw_scene() {
    glViewport(0, 0, W, H);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION); glLoadIdentity(); glOrtho(0, W, H, 0, -1, 1);
    glMatrixMode(GL_MODELVIEW); glLoadIdentity();
    glBegin(GL_QUADS);
    // sky
    for (int i = 0; i < 40; i++) {
        float t = i / 39.f;
        float y0 = t * H * .55f, y1 = (t + 1 / 39.f) * H * .55f;
        unsigned char v = (unsigned char)(58 - 34 * t);
        glColor3ub(v, v + 2, v + 6);
        glVertex2f(0, y0); glVertex2f((float)W, y0); glVertex2f((float)W, y1); glVertex2f(0, y1);
    }
    // ground
    for (int i = 0; i < 20; i++) {
        float y0 = H * .55f + i * H * .0225f, y1 = y0 + H * .023f;
        unsigned char v = (unsigned char)(26 + i * .7f);
        glColor3ub(v, v + 1, v + 3);
        glVertex2f(0, y0); glVertex2f((float)W, y0); glVertex2f((float)W, y1); glVertex2f(0, y1);
    }
    // blocks / crates / buildings
    struct Blk { float x, y, w, h; unsigned char v; };
    Blk blocks[] = {
        { 40, 330, 190, 250, 34 }, { 250, 250, 120, 330, 44 }, { 390, 380, 230, 200, 28 },
        { 640, 300, 150, 280, 38 }, { 810, 210, 200, 370, 46 }, { 1030, 350, 210, 230, 30 },
        { 300, 500, 340, 150, 24 }, { 700, 520, 420, 130, 22 }, { 150, 120, 90, 90, 52 },
    };
    for (auto& b : blocks) {
        unsigned char v = b.v;
        glColor3ub(v, v + 1, v + 4);
        glVertex2f(b.x, b.y); glVertex2f(b.x + b.w, b.y);
        glVertex2f(b.x + b.w, b.y + b.h); glVertex2f(b.x, b.y + b.h);
        // lit top edge
        glColor3ub(v + 26, v + 27, v + 30);
        glVertex2f(b.x, b.y); glVertex2f(b.x + b.w, b.y);
        glVertex2f(b.x + b.w, b.y + 10); glVertex2f(b.x, b.y + 10);
        // windows
        glColor3ub(v + 42, v + 40, v + 30);
        for (float wy = b.y + 26; wy < b.y + b.h - 18; wy += 44) {
            for (float wx = b.x + 18; wx < b.x + b.w - 16; wx += 46) {
                if (((int)(wx + wy)) % 3 == 0) {
                    glVertex2f(wx, wy); glVertex2f(wx + 16, wy);
                    glVertex2f(wx + 16, wy + 20); glVertex2f(wx, wy + 20);
                }
            }
        }
    }
    glEnd();
}

static LRESULT CALLBACK wnd_proc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (m == WM_DESTROY) PostQuitMessage(0);
    return DefWindowProcA(h, m, w, l);
}

static bool init_gl(HINSTANCE inst) {
    WNDCLASSA wc = {};
    wc.lpfnWndProc = wnd_proc;
    wc.hInstance = inst;
    wc.lpszClassName = "toker_preview";
    wc.hCursor = LoadCursorA(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    RegisterClassA(&wc);

    RECT r = { 0, 0, W, H };
    AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
    g_wnd = CreateWindowA("toker_preview", "toker ui preview", WS_OVERLAPPEDWINDOW,
                          CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top,
                          nullptr, nullptr, inst, nullptr);
    if (!g_wnd) return false;
    ShowWindow(g_wnd, SW_SHOW);
    UpdateWindow(g_wnd);

    g_dc = GetDC(g_wnd);
    PIXELFORMATDESCRIPTOR pfd = {};
    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    int pf = ChoosePixelFormat(g_dc, &pfd);
    if (!pf || !SetPixelFormat(g_dc, pf, &pfd)) return false;
    g_rc = wglCreateContext(g_dc);
    if (!g_rc) return false;
    wglMakeCurrent(g_dc, g_rc);
    return true;
}

static void write_bmp(const char* path, int w, int h, const unsigned char* rgb) {
    int row = (w * 3 + 3) & ~3;
    int size = row * h;
    BITMAPFILEHEADER bf = {};
    BITMAPINFOHEADER bi = {};
    bf.bfType = 0x4D42;
    bf.bfOffBits = sizeof(bf) + sizeof(bi);
    bf.bfSize = bf.bfOffBits + size;
    bi.biSize = sizeof(bi);
    bi.biWidth = w;
    bi.biHeight = h;      // positive = bottom-up, matches glReadPixels
    bi.biPlanes = 1;
    bi.biBitCount = 24;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = size;

    FILE* f = nullptr;
    if (fopen_s(&f, path, "wb") != 0 || !f) return;
    fwrite(&bf, sizeof(bf), 1, f);
    fwrite(&bi, sizeof(bi), 1, f);
    std::vector<unsigned char> line(row, 0);
    for (int y = 0; y < h; y++) {
        const unsigned char* src = rgb + (size_t)y * w * 3;
        for (int x = 0; x < w; x++) {
            line[x * 3 + 0] = src[x * 3 + 2];
            line[x * 3 + 1] = src[x * 3 + 1];
            line[x * 3 + 2] = src[x * 3 + 0];
        }
        fwrite(line.data(), row, 1, f);
    }
    fclose(f);
}

int main(int argc, char** argv) {
    int page = (argc > 1) ? atoi(argv[1]) : 0;
    const char* out = (argc > 2) ? argv[2] : "preview.bmp";

    HINSTANCE inst = GetModuleHandleA(nullptr);
    if (!init_gl(inst)) { printf("gl init failed\n"); return 1; }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    ui::load_fonts();
    ui::apply_style();
    ImGui_ImplWin32_Init(g_wnd);
    ImGui_ImplOpenGL2_Init();

    ui::page_index() = page;
    ui::State st;
    st.eng = st.pm = st.si = true;
    st.fps = 143.f;
    st.players = 12;
    st.eng_addr = 0x0DEAD000;
    st.pm_addr = 0x0DEAD100;
    st.si_addr = 0x0DEAD200;
    st.punch[0] = 1.24f;
    st.punch[1] = -0.42f;
    st.punch[2] = 0.f;
    st.flags = 0x209;
    st.on_ground = true;
    st.vel[0] = 241.f; st.vel[1] = 58.f; st.vel[2] = 0.f;
    st.speed = 248.f;
    bool open = true;

    std::vector<unsigned char> px((size_t)W * H * 3);

    for (int f = 0; f < 50; f++) {
        MSG msg;
        while (PeekMessageA(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageA(&msg);
        }
        glViewport(0, 0, W, H);
        glClearColor(0.035f, 0.037f, 0.042f, 1.f);
        glClear(GL_COLOR_BUFFER_BIT);
        draw_scene();
        ui::capture_backdrop();

        ImGui_ImplOpenGL2_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        ui::draw(st, &open);
        ImGui::Render();
        ImGui_ImplOpenGL2_RenderDrawData(ImGui::GetDrawData());

        if (f == 49) {
            glReadPixels(0, 0, W, H, GL_RGB, GL_UNSIGNED_BYTE, px.data());
            write_bmp(out, W, H, px.data());
        }
        SwapBuffers(g_dc);
        Sleep(16);
    }

    ImGui_ImplOpenGL2_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    wglMakeCurrent(nullptr, nullptr);
    wglDeleteContext(g_rc);
    ReleaseDC(g_wnd, g_dc);
    DestroyWindow(g_wnd);
    return 0;
}
