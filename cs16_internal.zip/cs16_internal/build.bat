@echo off
set COMPILER_PATH=C:\Users\ozere\AppData\Local\Microsoft\WinGet\Packages\MartinStorsjo.LLVM-MinGW.UCRT_Microsoft.Winget.Source_8wekyb3d8bbwe\llvm-mingw-20260616-ucrt-x86_64\bin
set GXX=%COMPILER_PATH%\i686-w64-mingw32-g++.exe
set GCC=%COMPILER_PATH%\i686-w64-mingw32-gcc.exe

echo [*] Building MinHook (x86)...
%GCC% -O2 -c minhook/src/buffer.c -o minhook_buffer.o -Iminhook/include
%GCC% -O2 -c minhook/src/hook.c -o minhook_hook.o -Iminhook/include
%GCC% -O2 -c minhook/src/trampoline.c -o minhook_trampoline.o -Iminhook/include
%GCC% -O2 -c minhook/src/hde/hde32.c -o minhook_hde32.o -Iminhook/include

echo [*] Building ImGui (x86)...
%GXX% -O2 -std=c++17 -c imgui/imgui.cpp -o imgui.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/imgui_draw.cpp -o imgui_draw.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/imgui_tables.cpp -o imgui_tables.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/imgui_widgets.cpp -o imgui_widgets.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/backends/imgui_impl_win32.cpp -o imgui_impl_win32.o -Iimgui
%GXX% -O2 -std=c++17 -c imgui/backends/imgui_impl_opengl2.cpp -o imgui_impl_opengl2.o -Iimgui

echo [*] Building DLL (toker_cs16.dll)...
%GXX% -O2 -shared -std=c++17 src/main.cpp imgui*.o minhook*.o -o toker_cs16.dll -Iimgui -lopengl32 -lgdi32 -luser32 -ldwmapi -lpsapi -static -s

echo [*] Building Loader (toker_loader.exe)...
%GXX% -O2 -std=c++17 loader/loader.cpp -o toker_loader.exe -static -s

echo [*] Cleaning up object files...
del *.o

echo [!] Done! toker_cs16.dll and toker_loader.exe generated.

